#ifdef E_TYPEDEFS
#else
#ifndef E_STOLEN_H
#define E_STOLEN_H

EAPI int  e_stolen_win_get(Ecore_X_Window win);
EAPI void e_stolen_win_add(Ecore_X_Window win);
EAPI void e_stolen_win_del(Ecore_X_Window win);

#endif
#endif
