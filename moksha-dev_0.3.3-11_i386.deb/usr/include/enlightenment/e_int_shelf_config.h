#ifdef E_TYPEDEFS
#else
#ifndef E_INT_SHELF_CONFIG_H
#define E_INT_SHELF_CONFIG_H

EAPI void e_int_shelf_config(E_Shelf *es);

#endif
#endif
