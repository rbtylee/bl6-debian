#ifndef E_UPDATE_H
# define E_UPDATE_H

EINTERN int		 e_update_init(void);
EINTERN int		 e_update_shutdown(void);

#endif
