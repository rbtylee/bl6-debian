#ifdef E_TYPEDEFS
#else
#ifndef E_INT_BORDER_PROP_H
#define E_INT_BORDER_PROP_H

EAPI void e_int_border_prop(E_Border *bd);

#endif
#endif
