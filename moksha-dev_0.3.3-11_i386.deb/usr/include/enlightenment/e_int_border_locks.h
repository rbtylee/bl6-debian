#ifdef E_TYPEDEFS
#else
#ifndef E_INT_BORDER_LOCKS_H
#define E_INT_BORDER_LOCKS_H

EAPI void e_int_border_locks(E_Border *bd);

#endif
#endif
